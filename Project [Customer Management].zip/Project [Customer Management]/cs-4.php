<?php
include "db_connect.php";
if(isset($_POST['submit']))
{
    $name = $_POST['name'];
    $age = $_POST['age'];
    $email = $_POST['email'];
    $num2 = $_POST['num2'];
    $cal = $age + $num2;

    db();
    $insertQuery = "INSERT INTO info(name,age,email,num2,cal) VALUES ('$name','$age','$email','$num2','$cal')";
    $insertInfo = mysqli_query($link,$insertQuery);
    if($insertInfo)
    {
        echo "works";
    }else
    {
        echo mysqli_error($link);
    }


}

$showTable = "SELECT name,age,email,num2,cal FROM info";
$result = mysqli_query($link, $showTable);

if(mysqli_num_rows($result)>0)
{
    echo "<table><tr><th>name</th><th>age</th><th>email</th><th>num2</th><th>cal</th></tr>";
    while($row = mysqli_fetch_assoc($result))
    {
        echo "<tr>
            <td>" . $row["name"]. "</td><td>" . $row["age"]. "</td><td>" . $row["email"]. "</td><td>" . $row["num2"]. "</td><td>" . $row["cal"]. "</td>";
        echo "<td><a href='delete.php? delete =$row[age]'>delete</a></td>";
        echo "</tr>";

    }
    echo "</table>";
}
else
{
    echo "0 results";
}

mysqli_close($link);

?>
<?php

include "db_connect.php";

$age = $_GET['age'];

$delete = mysqli_query($link,"delete from info where age = '$age'"); // delete query

if($delete)
{
    header("location:create.php");
    exit;
}
else
{
    echo "Error";
}
?>

$age = $_GET['delete'];

$stmt = mysqli_prepare($link,"delete from info where age = ?");
mysqli_stmt_bind_param($stmt, "i", $age);
$delete = mysqli_stmt_execute($stmt);
